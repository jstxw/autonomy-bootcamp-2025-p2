from . import crc8, crc16, crc32, crc64
from .__info__ import (
    __author__,
    __author_email__,
    __description__,
    __issues__,
    __license__,
    __title__,
    __url__,
    __version__,
)
